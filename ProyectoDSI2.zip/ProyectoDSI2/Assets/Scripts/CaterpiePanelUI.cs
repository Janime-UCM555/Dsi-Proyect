﻿using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UIElements;

public class CaterpiePanelUI : MonoBehaviour
{
    private CaterpieData caterpie;
    private Slider felicidadSlider, energiaSlider;
    private Button alimentarBtn, jugarBtn, curarBtn, liberarBtn;
    private CustomController estadoVisual;

    private void Start()
    {
        caterpie = GameManager.Instance.caterpie;
        var root = GetComponent<UIDocument>().rootVisualElement;

        // Configurar elementos UI
        estadoVisual = root.Q<CustomController>("EstadoVisual");
        felicidadSlider = root.Q<Slider>("FelicidadSlider");
        energiaSlider = root.Q<Slider>("EnergiaSlider");
        alimentarBtn = root.Q<Button>("AlimentarBtn");
        jugarBtn = root.Q<Button>("JugarBtn");
        curarBtn = root.Q<Button>("CurarBtn");
        liberarBtn = root.Q<Button>("LiberarBtn");

        ActualizarUI();

        // Configurar eventos de botones
        alimentarBtn.clicked += () => {
            caterpie.felicidad += 1;
            ActualizarUI();
            GameManager.Instance.SaveGameData(); // Guardar cambios
        };

        jugarBtn.clicked += () => {
            caterpie.energia -= 1;
            caterpie.felicidad += 2;
            ActualizarUI();
            GameManager.Instance.SaveGameData(); // Guardar cambios
        };

        curarBtn.clicked += () => {
            caterpie.energia += 1;
            ActualizarUI();
            GameManager.Instance.SaveGameData(); // Guardar cambios
        };

        liberarBtn.clicked += () => {
            GameManager.Instance.currentNodeID = "liberacion";
            GameManager.Instance.SaveGameData(); // Guardar cambios
            SceneManager.LoadScene("Historia");
        };

        // Botón para volver a la historia
        var volverBtn = new Button
        {
            text = "Volver a la Historia",
            name = "VolverBtn"
        };
        volverBtn.clicked += () => {
            GameManager.Instance.SaveGameData(); // Guardar antes de salir
            SceneManager.LoadScene("Historia");
        };
        root.Add(volverBtn);
    }

    void ActualizarUI()
    {
        felicidadSlider.value = caterpie.felicidad;
        energiaSlider.value = caterpie.energia;
        estadoVisual.Estado = caterpie.felicidad;
        estadoVisual.UpdateUI();
    }
}