﻿using UnityEngine;
using UnityEngine.UIElements;
using UnityEngine.SceneManagement;

public class MainMenuUI : MonoBehaviour
{
    private Button _newGameBtn;
    private Button _continueBtn;
    private Button _exitBtn;

    private void OnEnable()
    {
        var root = GetComponent<UIDocument>().rootVisualElement;

        _newGameBtn = root.Q<Button>("NuevaPartida");
        _continueBtn = root.Q<Button>("ContinueBtn");
        _exitBtn = root.Q<Button>("Salir");

        // Configurar botones
        _newGameBtn.clicked += StartNewGame;
        _continueBtn.clicked += ContinueGame;
        _exitBtn.clicked += () => Application.Quit();

        // Solo mostrar continuar si hay partida guardada
        _continueBtn.style.display = PlayerPrefs.HasKey("SaveData") ?
            DisplayStyle.Flex : DisplayStyle.None;
    }

    private void StartNewGame()
    {
        GameManager.Instance.StartNewGame();
        SceneManager.LoadScene("Historia");
    }

    private void ContinueGame()
    {
        GameManager.Instance.ContinueGame();
        SceneManager.LoadScene("Historia");
    }
}