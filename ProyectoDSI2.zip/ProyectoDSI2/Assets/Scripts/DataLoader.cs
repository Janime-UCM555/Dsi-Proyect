﻿using UnityEngine;
using System.IO;

public static class DataLoader
{
    private static string ruta => Path.Combine(Application.persistentDataPath, "caterpies.json");

    public static void Guardar(CaterpieData data)
    {
        string json = JsonUtility.ToJson(data, true);
        File.WriteAllText(ruta, json);
        Debug.Log("Datos guardados en: " + ruta);
    }

    public static CaterpieData Cargar()
    {
        if (File.Exists(ruta))
        {
            string json = File.ReadAllText(ruta);
            return JsonUtility.FromJson<CaterpieData>(json);
        }
        return null;
    }
}