using UnityEngine;
using UnityEngine.UIElements;
using UnityEngine.SceneManagement;

public class EndingUI : MonoBehaviour
{
    private Label finalTexto;
    private Button volverBtn;

    private void OnEnable()
    {
        var root = GetComponent<UIDocument>().rootVisualElement;
        finalTexto = root.Q<Label>("FinalTexto");
        volverBtn = root.Q<Button>("VolverBtn");

        string final = GameManager.Instance.caterpie.felicidad >= 5 ? "Final Feliz" : "Final Triste";
        finalTexto.text = final;
        volverBtn.clicked += () => SceneManager.LoadScene("MainMenu");
    }
}