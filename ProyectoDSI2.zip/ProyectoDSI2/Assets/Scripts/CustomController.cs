﻿using UnityEngine;
using UnityEngine.UIElements;

public class CustomController : VisualElement
{
    [SerializeField, Range(0, 5)]
    public int Estado;  // Atributo que varía de 0 a 5
    [SerializeField]
    string imageName = "Corazon";  // Atributo string para el nombre de la imagen

    private VisualElement[] marcadores;  // Array para los marcadores

    public CustomController()
    {
        // Cargar el Template UXML
        var visualTree = Resources.Load<VisualTreeAsset>("ContenedorCajasFinal");
        if (visualTree != null)
        {
            visualTree.CloneTree(this); // Instancia la estructura del UXML en este control
        }

        // Obtener los marcadores desde el UXML por nombre
        marcadores = new VisualElement[5];
        for (int i = 0; i < 5; i++)
        {
            marcadores[i] = this.Q<VisualElement>($"Marcador{i + 1}");  // Obtiene los 5 marcadores
        }

        // Aplicar estilos
        styleSheets.Add(Resources.Load<StyleSheet>("P4JaimeYMichel")); // Cargar el USS

        // Actualizar la UI
        UpdateUI();
    }

    // Método para actualizar la UI dependiendo del estado y la imagen
    public void UpdateUI()
    {
        for (int i = 0; i < 5; i++)
        {
            if (marcadores[i] != null)
            {
                // Limpiar las clases anteriores
                marcadores[i].RemoveFromClassList("marcador");
                marcadores[i].RemoveFromClassList("desactivado");

                // Si el estado de este marcador es mayor que el índice, debe estar activo (marcador)
                if (i < Estado)
                {
                    marcadores[i].AddToClassList("marcador");
                }
                else
                {
                    marcadores[i].AddToClassList("desactivado");
                }

                // Cargar la imagen como Texture2D
                Texture2D texture = Resources.Load<Texture2D>($"{imageName}");

                // Si la imagen se carga correctamente
                if (texture != null)
                {
                    // Cambiar la imagen de fondo del marcador
                    marcadores[i].style.backgroundImage = new StyleBackground(texture);  // Asignar la textura al fondo del marcador
                }
            }
        }
    }

    public new class UxmlFactory : UxmlFactory<CustomController, UxmlTraits> { }

    public new class UxmlTraits : VisualElement.UxmlTraits
    {
        private UxmlIntAttributeDescription stateAttr = new UxmlIntAttributeDescription { name = "Estado", defaultValue = 5 };
        private UxmlStringAttributeDescription imageNameAttr = new UxmlStringAttributeDescription { name = "ImageName", defaultValue = "Venasaur" };

        public override void Init(VisualElement ve, IUxmlAttributes bag, CreationContext cc)
        {
            base.Init(ve, bag, cc);
            var controller = ve as CustomController;

            controller.Estado = stateAttr.GetValueFromBag(bag, cc);  // Asignar el valor de estado desde UXML
            controller.imageName = imageNameAttr.GetValueFromBag(bag, cc);
            controller.UpdateUI();
        }
    }
}