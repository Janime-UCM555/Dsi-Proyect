﻿using UnityEngine;
using UnityEngine.SceneManagement;

public static class SceneController
{
    public static void CargarEscena(string nombreEscena)
    {
        SceneManager.LoadScene(nombreEscena);
    }

    public static void SalirDelJuego()
    {
        Application.Quit();
    }
}