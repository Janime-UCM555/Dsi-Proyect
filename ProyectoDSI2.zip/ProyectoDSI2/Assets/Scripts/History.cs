﻿using UnityEngine;
using UnityEngine.UIElements;
using System.Collections.Generic;
using System.Linq;
using UnityEngine.SceneManagement;

[RequireComponent(typeof(UIDocument))]
public class History : MonoBehaviour
{
    // Elementos UI
    private Label storyText;
    private Button option1Button;
    private Button option2Button;
    private Button caterpieButton;
    private Button menuButton;

    // Datos de la historia
    private List<StoryNode> storyNodes = new List<StoryNode>();
    private StoryNode currentNode;

    private void OnEnable()
    {
        try
        {
            InitializeUI();
            LoadStoryData();

            // Validación crítica
            if (storyNodes == null || storyNodes.Count == 0)
            {
                Debug.LogError("No se cargaron nodos de historia");
                CreateFallbackStory();
            }

            string startNode = GameManager.Instance?.currentNodeID ?? "inicio";
            ShowNode(startNode);
        }
        catch (System.Exception e)
        {
            Debug.LogError($"Error en OnEnable: {e.Message}");
            CreateFallbackStory();
            ShowNode("inicio");
        }
    }

    private void InitializeUI()
    {
        var root = GetComponent<UIDocument>().rootVisualElement;

        // Obtener elementos con verificación de null
        storyText = root.Q<Label>("StoryText") ?? throw new System.NullReferenceException("StoryText no encontrado");
        option1Button = root.Q<Button>("Option1Button") ?? throw new System.NullReferenceException("Option1Button no encontrado");
        option2Button = root.Q<Button>("Option2Button") ?? throw new System.NullReferenceException("Option2Button no encontrado");
        caterpieButton = root.Q<Button>("CaterpieButton");
        menuButton = root.Q<Button>("MenuButton");

        // Configurar eventos seguros
        if (caterpieButton != null) caterpieButton.clicked += OnCaterpieButtonClicked;
        if (menuButton != null) menuButton.clicked += OnMenuButtonClicked;
    }

    private void LoadStoryData()
    {
        TextAsset jsonFile = Resources.Load<TextAsset>("Datos/historia");
        if (jsonFile == null)
        {
            Debug.LogError("Archivo JSON no encontrado en Resources/Datos/historia");
            return;
        }

        try
        {
            StoryDataWrapper wrapper = JsonUtility.FromJson<StoryDataWrapper>(jsonFile.text);
            if (wrapper != null && wrapper.nodes != null)
            {
                // Mapear los nombres de campos del JSON a nuestra clase
                storyNodes = wrapper.nodes.Select(node => new StoryNode
                {
                    id = node.id,
                    text = node.texto,
                    options = node.opciones,
                    nextNodes = node.siguiente
                }).ToList();

                Debug.Log($"Se cargaron {storyNodes.Count} nodos de historia");
            }
            else
            {
                Debug.LogError("El wrapper o los nodos son null");
                storyNodes = new List<StoryNode>();
            }
        }
        catch (System.Exception e)
        {
            Debug.LogError($"Error al parsear JSON: {e.Message}");
        }
    }

    private void CreateFallbackStory()
    {
        storyNodes = new List<StoryNode>
        {
            new StoryNode
            {
                id = "inicio",
                text = "Historia no cargada. Usando nodo de respaldo.",
                options = new[] { "Continuar" },
                nextNodes = new[] { "inicio" }
            }
        };
    }

    private void ShowNode(string nodeID)
    {
        currentNode = storyNodes.FirstOrDefault(n => n.id == nodeID);
        if (currentNode == null)
        {
            Debug.LogWarning($"Nodo {nodeID} no encontrado. Usando primer nodo.");
            currentNode = storyNodes.FirstOrDefault();
        }

        if (currentNode == null)
        {
            Debug.LogError("No hay nodos disponibles");
            return;
        }

        storyText.text = currentNode.text;
        GameManager.Instance.currentNodeID = currentNode.id;
        GameManager.Instance.SaveGameData();

        SetupOptionButtons();
    }

    private void SetupOptionButtons()
    {
        // Resetear estado de los botones
        option1Button.style.display = DisplayStyle.None;
        option2Button.style.display = DisplayStyle.None;

        // Limpiar eventos previos
        option1Button.clicked -= () => HandleOptionSelection(0);
        option2Button.clicked -= () => HandleOptionSelection(1);

        // Validar nodo actual
        if (currentNode == null || currentNode.options == null || currentNode.options.Length == 0)
        {
            // Si no hay opciones, mostrar solo un botón para continuar
            option1Button.style.display = DisplayStyle.Flex;
            option1Button.text = "Continuar";
            option1Button.clicked += () => {
                if (currentNode.nextNodes != null && currentNode.nextNodes.Length > 0)
                {
                    ProcessNextNode(currentNode.nextNodes[0]);
                }
                else
                {
                    ShowNode("inicio");
                }
            };
            return;
        }

        // Configurar primer botón
        if (currentNode.options.Length > 0)
        {
            option1Button.style.display = DisplayStyle.Flex;
            option1Button.text = currentNode.options[0];
            option1Button.clicked += () => HandleOptionSelection(0);
        }

        // Configurar segundo botón
        if (currentNode.options.Length > 1)
        {
            option2Button.style.display = DisplayStyle.Flex;
            option2Button.text = currentNode.options[1];
            option2Button.clicked += () => HandleOptionSelection(1);
        }
    }

    private void HandleOptionSelection(int selectedOptionIndex)
    {
        if (currentNode == null || currentNode.nextNodes == null || selectedOptionIndex >= currentNode.nextNodes.Length)
        {
            Debug.LogError("Índice de opción inválido");
            ShowNode("inicio");
            return;
        }

        string selectedNodeId = currentNode.nextNodes[selectedOptionIndex];
        ProcessNextNode(selectedNodeId);
    }

    private void ProcessNextNode(string nextNodeID)
    {
        if (nextNodeID == "PANEL")
        {
            GameManager.Instance.needsCare = true;
            GameManager.Instance.pendingNode = currentNode.id;
            SceneManager.LoadScene("CaterpiePanel");
        }
        else if (nextNodeID.StartsWith("final_"))
        {
            SceneManager.LoadScene("Final");
        }
        else if (nextNodeID == "MENU")
        {
            SceneManager.LoadScene("MainMenu");
        }
        else
        {
            ShowNode(nextNodeID);
        }
    }

    private void OnCaterpieButtonClicked()
    {
        GameManager.Instance.pendingNode = currentNode.id;
        SceneManager.LoadScene("CaterpiePanel");
    }

    private void OnMenuButtonClicked()
    {
        SceneManager.LoadScene("MainMenu");
    }

    private void OnDisable()
    {
        if (caterpieButton != null) caterpieButton.clicked -= OnCaterpieButtonClicked;
        if (menuButton != null) menuButton.clicked -= OnMenuButtonClicked;
    }

    // Clases para deserialización del JSON
    [System.Serializable]
    private class StoryDataWrapper
    {
        public List<JsonStoryNode> nodes;
    }

    [System.Serializable]
    private class JsonStoryNode
    {
        public string id;
        public string texto;
        public string[] opciones;
        public string[] siguiente;
    }

    [System.Serializable]
    public class StoryNode
    {
        public string id;
        public string text;
        public string[] options;
        public string[] nextNodes;
    }
}