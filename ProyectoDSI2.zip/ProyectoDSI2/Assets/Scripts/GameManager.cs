﻿using UnityEngine;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;

    // Datos del Caterpie
    public CaterpieData caterpie;
    public string currentNodeID = "inicio";
    public bool needsCare = false;
    public string pendingNode;

    // Control de partida
    private bool _isNewGame = true;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        DontDestroyOnLoad(gameObject);
        LoadGameData();
    }

    public void StartNewGame()
    {
        // Resetear todos los datos
        caterpie = new CaterpieData
        {
            nombre = "Caterpie",
            mote = "Juicy",
            felicidad = 3,
            energia = 3,
            confianza = 2
        };
        currentNodeID = "inicio";
        needsCare = false;
        _isNewGame = true;

        SaveGameData();
    }

    public void ContinueGame()
    {
        _isNewGame = false;
        LoadGameData();
    }

    public void SaveGameData()
    {
        SaveData data = new SaveData
        {
            caterpie = this.caterpie,
            currentNodeID = this.currentNodeID,
            needsCare = this.needsCare
        };

        string json = JsonUtility.ToJson(data);
        PlayerPrefs.SetString("SaveData", json);
        PlayerPrefs.Save();
    }

    private void LoadGameData()
    {
        if (PlayerPrefs.HasKey("SaveData"))
        {
            string json = PlayerPrefs.GetString("SaveData");
            SaveData data = JsonUtility.FromJson<SaveData>(json);

            caterpie = data.caterpie ?? new CaterpieData();
            currentNodeID = data.currentNodeID ?? "inicio";
            needsCare = data.needsCare;
        }
    }

    [System.Serializable]
    private class SaveData
    {
        public CaterpieData caterpie;
        public string currentNodeID;
        public bool needsCare;
    }
}