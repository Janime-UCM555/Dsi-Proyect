[System.Serializable]
public class CaterpieData
{
    public string nombre;
    public string mote;
    public int felicidad;
    public int energia;
    public int confianza;
}
